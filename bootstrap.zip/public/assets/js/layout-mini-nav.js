(function($) {
    "use strict"

    new dzSettings({
        sidebarStyle: "mini"
    });


})(jQuery);