import Header from '@/Components/Header';
import Leftbar from '@/Components/Leftbar';
import React, { useEffect } from 'react'

export default function Layouts({children}) {
    useEffect(() => {
        feather.replace();
    }, []);

  return (
<div id="layout-wrapper">
    <Header></Header>
    <Leftbar></Leftbar>

    {children}

</div>

  )
}
